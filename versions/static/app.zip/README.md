﻿# Static Version (`versions/static`)

Versi ini independen dari `versions/rust-server` dan berjalan dengan pola:

- static file frontend (`index.html`, `styles.css`, `app.js`)
- EdgeOne Functions proxy (`edge-functions/api/proxy.js`) untuk request upstream tanpa masalah CORS

## Routing

- Homepage: `/`
- Reader chapter: `/<encoded_target_url>`
- Proxy function: `/api/proxy?url=<upstream_url>`

## Live Deployment

- URL: `https://mirror-komiku.edgeone.dev/`

Contoh reader URL:

- `/https%3A%2F%2Fkomiku.org%2Fmartial-peak-chapter-980%2F`

## Alur Kerja

1. User buka homepage dan input URL chapter Komiku.
2. App redirect ke `/<encoded_target_url>`.
3. Browser minta chapter HTML via `/api/proxy`.
4. Browser parse title + image URLs + next chapter URL.
5. Gambar ditampilkan **berurutan** dengan strategi `direct-first`:
   - coba URL upstream langsung dulu
   - fallback ke `/api/proxy` jika gagal
6. Setelah full-load chapter saat ini, app prefetch 5 chapter ke depan secara berurutan.
7. Prefetch image disimpan ke IndexedDB.
8. Saat pindah chapter lewat tombol Next, app pakai **local-first** (IndexedDB) dulu.

## Cache IndexedDB

- DB: `mirror_raw_static_db`
- Store: `chapters`
- Batas cache: 10 chapter
- Jika melebihi 10, chapter paling lama (`cached_at` terkecil) dihapus.

## Struktur File

- `index.html` : homepage + reader container
- `styles.css` : style UI
- `app.js` : parser, sequential loader, prefetch queue, IndexedDB logic
- `edge-functions/api/proxy.js` : server-side proxy untuk HTML/image upstream

## Deploy di EdgeOne Pages

1. Deploy folder `versions/static`.
2. Pastikan folder `edge-functions` ikut terdeploy.
3. Atur SPA rewrite:
   - semua path non-file -> `/index.html`
   - kecualikan path `/api/*` agar request tetap masuk ke function proxy
4. Opsional keamanan: set env `UPSTREAM_ALLOWLIST` (comma-separated), contoh:
   - `komiku.org,img.komiku.org`

## Catatan Keamanan Proxy

- Hanya menerima target `http`/`https`.
- Menolak `localhost` dan private IP.
- Jika `UPSTREAM_ALLOWLIST` diisi, host di luar allowlist akan ditolak (`403`).

## Optimasi Request Edge Function

- Chapter manifest disimpan in-memory cache di browser selama sesi.
- Parsing chapter yang sama tidak request `/api/proxy` berulang.
- Render gambar chapter aktif meminimalkan hit proxy karena hanya fallback saat direct load gagal.
- Request ke proxy memakai retry + exponential backoff + cooldown URL gagal (menghindari spam request berulang saat upstream/error).
- Request chapter HTML/blob yang identik dideduplikasi (`in-flight de-duplication`) supaya tidak menembak endpoint sama secara paralel.
- Proxy memakai `caches.default.match/put` agar upstream fetch berulang berkurang.
- Proxy menerapkan `Cache-Control` adaptif (image lebih lama, HTML lebih pendek) untuk menekan request ulang dari browser/edge cache.

## Catatan Testing Lokal

- `npx serve -s` hanya menjalankan static file, bukan function proxy.
- Test CORS fix end-to-end harus di environment EdgeOne Functions.

## Rujukan Dokumentasi EdgeOne

- Edge Functions (konsep, lifecycle, `waitUntil`): https://pages.edgeone.ai/document/161779710200866816
- `edgeone.json` (headers/cache/route rules): https://pages.edgeone.ai/document/162261069035167744
- Cache API (`cache.match`, `cache.put`, dll): https://intl.cloud.tencent.com/document/product/1145/47615
